package com.example.herogame.Entities;

public class Player {
    private int PlayerId;
    private int NationalId;
    private String PlayerName;
    private int HighScore;
    private int Level;

    public int getPlayerId() {
        return PlayerId;
    }

    public int getNationalId() {
        return NationalId;
    }

    public String getPlayerName() {
        return PlayerName;
    }

    public int getHighScore() {
        return HighScore;
    }

    public int getLevel() {
        return Level;
    }

    public void setPlayerId(int playerId) {
        PlayerId = playerId;
    }

    public void setNationalId(int nationalId) {
        NationalId = nationalId;
    }

    public void setPlayerName(String playerName) {
        PlayerName = playerName;
    }

    public void setHighScore(int highScore) {
        HighScore = highScore;
    }

    public void setLevel(int level) {
        Level = level;
    }

    public Player(int playId, int NatiId, String playName, int highScore, int level){
        PlayerId = playId;
        NationalId = NatiId;
        PlayerName = playName;
        HighScore = highScore;
        Level = level;
    }

    public void insertPlayer(int PlayerId,int NationalId, String playerName, int HighScore, int Level){
        setPlayerId(PlayerId);
        setNationalId(NationalId);
        setPlayerName(playerName);
        setHighScore(HighScore);
        setLevel(Level);
    }


}
