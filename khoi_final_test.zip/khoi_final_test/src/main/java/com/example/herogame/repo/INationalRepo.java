package com.example.herogame.repo;
import com.example.herogame.Entities.National;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface INationalRepo extends JpaRepository<National, Integer> {
    // JpaRepository provides all basic CRUD methods.
}