package com.example.herogame.Entities;

public class National {
    private int NationalId;
    private String NationalName;

    public int getNationalId() {
        return NationalId;
    }

    public String getNationalName() {
        return NationalName;
    }

    public void setNationalId(int nationalId) {
        NationalId = nationalId;
    }

    public void setNationalName(String nationalName) {
        NationalName = nationalName;
    }

    public National(int NatiId, String NatiName){
        NationalId = NatiId;
        NationalName = NatiName;
    }

    public void insertNational(int NationalId,String NationalName){
        setNationalId(NationalId);
        setNationalName(NationalName);
    }
}
