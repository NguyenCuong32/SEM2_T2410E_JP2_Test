create database HeroGame;
use HeroGame;

create table Player(
PlayerId int auto_increment primary key,
NationalId int ,
PlayerName nvarchar(256),
HighScore int,
Level int
);

create table National(
NationalId int auto_increment primary key,
NationalName nvarchar(256)
);

insert into Player(PlayerId,NationalId,PlayerName,HighScore,Level) values (1,1,'Player 1',100,2);
insert into Player(PlayerId,NationalId,PlayerName,HighScore,Level) values (2,2,'Player 2',1050,10);
insert into Player(PlayerId,NationalId,PlayerName,HighScore,Level) values (3,3,'Player 3',200,5);




