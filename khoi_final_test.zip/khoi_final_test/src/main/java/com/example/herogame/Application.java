package com.example.herogame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeroGameApplicationTests {

	@Test
	void contextLoads() {
	}

}